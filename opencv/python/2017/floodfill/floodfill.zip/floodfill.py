import cv2
import numpy as np

tolerancia = 1
point = (0, 0)

def floodFill():
    src = img.copy()

    connectivity = 4
    flags = connectivity
    flags |= cv2.FLOODFILL_FIXED_RANGE

    cv2.floodFill(src, None, point, (0, 255, 255), (tolerancia,) * 3, (tolerancia,) * 3, flags)
    cv2.imshow('relleno', src)

def mouse_clic(event, x, y, flags, param):
    if event == cv2.EVENT_LBUTTONUP:
        global point
        point = (x, y)
        floodFill()

def trackbar_value(value):
    global tolerancia
    tolerancia = value
    floodFill()

def main():
    global img

    winname = 'Flood fill'
    img = cv2.imread('data/image.png')

    cv2.namedWindow(winname)
    cv2.setMouseCallback(winname, mouse_clic, img)
    cv2.createTrackbar('Tolerancia', winname, tolerancia, 100, trackbar_value)

    while(1):
        cv2.imshow(winname, img)
        if cv2.waitKey(20) & 0xFF == 27:
            break

    cv2.destroyAllWindows()
    
if __name__ == '__main__':
    main()

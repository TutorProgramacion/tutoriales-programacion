package com.carmelo.detector;

import android.Manifest;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.SurfaceView;

import org.opencv.android.BaseLoaderCallback;
import org.opencv.android.CameraBridgeViewBase;
import org.opencv.android.CameraBridgeViewBase.CvCameraViewListener;
import org.opencv.android.JavaCameraView;
import org.opencv.android.LoaderCallbackInterface;
import org.opencv.android.OpenCVLoader;
import org.opencv.core.Mat;
import org.opencv.core.MatOfRect;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;
import org.opencv.objdetect.CascadeClassifier;

public class DetectorActivity extends AppCompatActivity implements CvCameraViewListener {

    private static final String TAG = "CMA::DetectorActivity";

    private CameraBridgeViewBase cameraView = null;
    private CascadeClassifier detector = null;

    private Mat gray;

    private BaseLoaderCallback ocvLoaderCallback = new BaseLoaderCallback(this) {
        @Override
        public void onManagerConnected(int status) {
            switch (status) {
                case LoaderCallbackInterface.SUCCESS:

                    Log.i(TAG, "Carga de OpenCV correcta...");
                    cameraView.enableView();

                    String path = CascadeHelper.generateXmlPath(this.mAppContext, R.raw.haarcascade_frontalface_alt2);

                    if (path != null) {
                        detector = new CascadeClassifier(path);

                        if (!detector.empty()) {
                            Log.i(TAG, "Cargar clasificador .xml, archivo: " + path);
                        }
                    }

                    break;
                default:
                    super.onManagerConnected(status);
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestPermissions(new String[]{ Manifest.permission.CAMERA }, 1);

        cameraView = new JavaCameraView(this, CameraBridgeViewBase.CAMERA_ID_ANY);

        cameraView.setVisibility(SurfaceView.VISIBLE);
        cameraView.setCvCameraViewListener(this);
        cameraView.enableFpsMeter();

        setContentView(cameraView);
    }

    @Override
    protected void onResume() {

        super.onResume();

        Log.i(TAG, "Cargando librería .so incluida en proyecto...");
        if (!OpenCVLoader.initDebug()) {

            Log.i(TAG, "Cargando librería con OpenCV Manager...");
            OpenCVLoader.initAsync(OpenCVLoader.OPENCV_VERSION_3_0_0, this, ocvLoaderCallback);

        } else {
            ocvLoaderCallback.onManagerConnected(LoaderCallbackInterface.SUCCESS);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();

        if (cameraView != null)
            cameraView.disableView();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (cameraView != null)
            cameraView.disableView();
    }

    @Override
    public void onCameraViewStarted(int width, int height) {
        gray = new Mat();
    }

    @Override
    public void onCameraViewStopped() {
        gray.release();
    }

    @Override
    public Mat onCameraFrame(Mat src) {

        //Core.flip(src, src, 1);

        Imgproc.cvtColor(src, gray, Imgproc.COLOR_BGR2GRAY);
        Imgproc.equalizeHist(gray, gray);

        MatOfRect faces = new MatOfRect();
        if (detector != null && !detector.empty()) {
            detector.detectMultiScale(gray, faces, 1.1, 2, 2, new Size(200, 200), new Size());
        }

        for (Rect rc : faces.toList()) {
            Imgproc.rectangle(src, rc.tl(), rc.br(), new Scalar(0, 255, 0));
        }

        return src;
    }

}

package carmelo.spring.config.web;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.access.AccessDeniedHandler;

public class MyAccessDeniedHandlerImpl implements AccessDeniedHandler {

    private static final Logger LOG = Logger.getLogger(MyAccessDeniedHandlerImpl.class.getName());

    @Override
    public void handle(HttpServletRequest request, HttpServletResponse response, AccessDeniedException ade)
            throws IOException, ServletException {

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        
        if (auth != null) {
            LOG.log(Level.WARNING, "User: {0} attempted to access the protected URL: {1}", 
                    new Object[]{ auth.getName(), request.getRequestURI() });
        }

        response.sendRedirect(request.getContextPath() + "/accessdenied");
    }

}

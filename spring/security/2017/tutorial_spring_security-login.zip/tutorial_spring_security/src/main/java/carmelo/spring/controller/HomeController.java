package carmelo.spring.controller;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {

    @RequestMapping(value = {"/", "/home"})
    public String home(Model model) {

        model.addAttribute("nombre_usuario", SecurityContextHolder
                .getContext().getAuthentication().getName());

        return "home";
    }

    @RequestMapping("/ventas")
    public String user(Model model) {
        return "ventas";
    }
}

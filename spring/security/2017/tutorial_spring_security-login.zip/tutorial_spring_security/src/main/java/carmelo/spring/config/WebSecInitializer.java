
package carmelo.spring.config;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class WebSecInitializer extends AbstractSecurityWebApplicationInitializer {
    
}

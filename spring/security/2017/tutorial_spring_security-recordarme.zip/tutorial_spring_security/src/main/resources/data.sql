/*
INSERT INTO USUARIO (`id`, `activo`, `apellido`, `email`, `nombre`, `password`) VALUES(1, true, 'root_apellido', 'root@gamil.com', 'root_nombre', 'root');
INSERT INTO USUARIO (`id`, `activo`, `apellido`, `email`, `nombre`, `password`) VALUES(2, true, 'user_apellido', 'user@gamil.com', 'user_nombre', 'user');

INSERT INTO ROLES (`id`, `nombre`) VALUES(1, 'ROLE_ROOT');
INSERT INTO ROLES (`id`, `nombre`) VALUES(2, 'ROLE_USER');

INSERT INTO USUARIO_ROLES (`usuarios_id`, `roles_id`) VALUES(1, 1);
INSERT INTO USUARIO_ROLES (`usuarios_id`, `roles_id`) VALUES(1, 2);
INSERT INTO USUARIO_ROLES (`usuarios_id`, `roles_id`) VALUES(2, 1);
*/
/*
INSERT INTO "PUBLIC"."USUARIO"
( "ID", "ACTIVO", "APELLIDO", "EMAIL", "NOMBRE", "PASSWORD" )
VALUES(1, true, 'root_apellido', 'root@gamil.com', 'root', 'root');

INSERT INTO "PUBLIC"."USUARIO"
( "ID", "ACTIVO", "APELLIDO", "EMAIL", "NOMBRE", "PASSWORD" )
VALUES(2, true, 'user_apellido', 'user@gamil.com', 'user', 'user');


INSERT INTO "PUBLIC"."ROLES" ( "ID", "NOMBRE" ) VALUES (1, 'ROLE_ROOT')
INSERT INTO "PUBLIC"."ROLES" ( "ID", "NOMBRE" ) VALUES (2, 'ROLE_USER')


INSERT INTO "PUBLIC"."USUARIO_ROLES" ( "USUARIOS_ID", "ROLES_ID" ) VALUES (1, 1)
INSERT INTO "PUBLIC"."USUARIO_ROLES" ( "USUARIOS_ID", "ROLES_ID" ) VALUES (1, 2)
INSERT INTO "PUBLIC"."USUARIO_ROLES" ( "USUARIOS_ID", "ROLES_ID" ) VALUES (2, 1)
*/
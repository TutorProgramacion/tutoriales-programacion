package carmelo.spring.controller;

import carmelo.spring.data.model.Usuario;
import carmelo.spring.data.repository.UsuarioRepository;
import java.util.Arrays;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UsuarioRepository usuarios;
    
    @Autowired 
    private PasswordEncoder encoder;

    @RequestMapping(value = "/register", method = RequestMethod.GET)
    public String register(Model model) {
        model.addAttribute("usuario", new Usuario());
        return "usuario";
    }

    @RequestMapping(value = "/register", method = RequestMethod.POST)
    public String register(@Valid Usuario user, BindingResult result) {
        
        if(result.hasErrors()) {
            return "usuario";
        }
        
        String password = encoder.encode(user.getPassword());
        user.setPassword(password);
        
        usuarios.save(user);
        
        return "redirect:/";
    }

    @ModelAttribute("roles")
    public List<String> getRoles() {
        return Arrays.asList("ROLE_ADMIN", "ROLE_USER");
    }  
}

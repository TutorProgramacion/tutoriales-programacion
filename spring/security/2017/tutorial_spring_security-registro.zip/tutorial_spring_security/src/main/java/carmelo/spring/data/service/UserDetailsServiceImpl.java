package carmelo.spring.data.service;

import carmelo.spring.data.model.Usuario;
import carmelo.spring.data.repository.UsuarioRepository;

import java.util.stream.Collectors;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

@Component
public class UserDetailsServiceImpl implements UserDetailsService {

    @Autowired
    private UsuarioRepository usuarios;

    @Override
    public UserDetails loadUserByUsername(String string) throws UsernameNotFoundException {

        Usuario usr = usuarios.findByNombre(string);
        
        List<SimpleGrantedAuthority> auths = usr.getRoles().stream()
                .map(rol -> new SimpleGrantedAuthority(rol))
                .collect(Collectors.toList());

        return new User(usr.getNombre(), usr.getPassword(), auths);
    }
}

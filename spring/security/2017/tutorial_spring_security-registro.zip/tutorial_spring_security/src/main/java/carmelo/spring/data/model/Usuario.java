package carmelo.spring.data.model;

import lombok.Data;
import java.util.List;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

@Data
@Entity
public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotEmpty(message = "Debe indicar el nombre del usuario.")
    private String nombre;

    @NotEmpty(message = "Debe indicar el apellido del usuario.")
    private String apellido;

    @NotEmpty(message = "Se requiere una contraseña para poder acceder.")
    private String password;

    @Email(message = "La dirección de correo electrónico es incorrecta.")
    private String email;

    @NotEmpty(message = "Seleccione los roles para el usuario.")
    @ElementCollection(fetch = FetchType.EAGER)
    private List<String> roles;

}

package carmelo.spring.data.model;

import java.util.List;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Size;
import lombok.Data;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

@Data
@Entity
public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotEmpty
    private String nombre;
    
    @NotEmpty
    private String apellido;
    
    @Size(min = 3)
    private String password;
    
    @Email
    private String email;
    
    @NotEmpty
    @ElementCollection(fetch = FetchType.EAGER)
    private List<String> roles;

}

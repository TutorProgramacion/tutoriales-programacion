package carmelo.web;

import carmelo.data.model.Person;
import com.vaadin.data.Binder;
import com.vaadin.data.BinderValidationStatus;
import com.vaadin.data.validator.EmailValidator;
import com.vaadin.icons.VaadinIcons;
import com.vaadin.ui.Button;
import com.vaadin.ui.FormLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.NativeSelect;
import com.vaadin.ui.Notification;
import com.vaadin.ui.PasswordField;
import com.vaadin.ui.Slider;
import com.vaadin.ui.TextField;

public class PersonForm extends FormLayout {

    Binder<Person> binder = new Binder<>(Person.class);

    TextField name = new TextField("Nombre");
    TextField email = new TextField("Correo");
    PasswordField pass = new PasswordField("Contraseña");
    Slider edad = new Slider("Edad");
    NativeSelect<String> provincia = new NativeSelect<>("Residencia");

    Person person;

    public PersonForm() {
        initUI();
        initBinder();
        initBean();
    }

    private void initUI() {

        name.setPlaceholder("Escribe tu nombre");
        name.setWidth("100%");
        name.setIcon(VaadinIcons.USER);

        email.setPlaceholder("Escribe tu correo");
        email.setWidth("100%");
        email.setIcon(VaadinIcons.ENVELOPE);

        pass.setPlaceholder("Escribe tu password");
        pass.setWidth("100%");
        pass.setIcon(VaadinIcons.PASSWORD);

        edad.setWidth("100%");
        edad.setIcon(VaadinIcons.CALENDAR_USER);

        provincia.setItems("Panama", "Veraguas", "Colon", "Herrera", "otro.");
        provincia.setIcon(VaadinIcons.HOME);

        Button btnValidate = new Button("Validar", this::validate);
        btnValidate.setIcon(VaadinIcons.BUG);

        Button btnReset = new Button("Resetear", e -> initBean());
        btnReset.setIcon(VaadinIcons.TRASH);

        HorizontalLayout btns = new HorizontalLayout(btnValidate, btnReset);

        this.addComponents(name, email, pass, edad, provincia, btns);
    }

    private void initBinder() {

        binder.forField(edad)
                .withValidator(age -> age >= 18, "Debes ser mayor de edad.")
                .withConverter(Double::intValue, Integer::doubleValue)
                .bind(Person::getAge, Person::setAge);

        binder.forField(name)
                .asRequired("Debes indicar el nombre")
                .bind("name");

        binder.forField(email)
                .withValidator(new EmailValidator("Este correo es incorrecto."))
                .bind("email");

        binder.forField(pass)
                .asRequired("Debes crear una contraseña")
                .withValidator(new PersonPassValidator())
                .bind("pass");

        binder.forField(provincia)
                .asRequired("Cual es tu lugar de residencia")
                .bind(Person::getProvincia, Person::setProvincia);
    }

    private void initBean() {

        person = new Person();
        person.setName("");
        person.setEmail("");
        person.setAge(0);
        person.setPass("");

        binder.readBean(person);
    }

    private void validate(Button.ClickEvent event) {

        BinderValidationStatus<Person> status = binder.validate();
        
        if (status.hasErrors()) {
            Notification.show(String.format(
                    "Se han encontrado %d errores.",
                    + status.getValidationErrors().size()));
        }
    }

}

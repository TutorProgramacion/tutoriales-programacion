package carmelo.web;

import com.vaadin.server.VaadinRequest;
import com.vaadin.shared.ui.ContentMode;
import com.vaadin.spring.annotation.SpringUI;
import com.vaadin.ui.Label;
import com.vaadin.ui.UI;
import com.vaadin.ui.VerticalLayout;

@SpringUI(path = "/person")
public class PersonUI extends UI {

    @Override
    protected void init(VaadinRequest request) {

        Label lbl = new Label("<h1>Spring Boot Vaadin Validation</h1>", ContentMode.HTML);
        
        PersonForm form = new PersonForm();

        VerticalLayout root = new VerticalLayout(lbl, form);

        setContent(root);
    }
}

package carmelo.web;

import com.vaadin.data.ValidationResult;
import com.vaadin.data.Validator;
import com.vaadin.data.ValueContext;

public class PersonPassValidator implements Validator<String> {

    @Override
    public ValidationResult apply(String value, ValueContext context) {
        if (value.trim().length() >= 8) {
            
            boolean digit = false;
            boolean letter = false;
            
            for (int i = 0; i < value.length(); i++) {
                digit |= Character.isDigit(value.charAt(i));
                letter |= Character.isLetter(value.charAt(i));
            }
            
            if(digit && letter){
                return ValidationResult.ok();
            }else {
                return ValidationResult.error("La contraseña debe contener letras y numeros.");
            }
        } else {
            return ValidationResult.error("La contraseña debe tener un minimo de 8 caracteres.");
        }
    }

}

package hello;

import com.vaadin.annotations.Title;
import com.vaadin.server.VaadinRequest;
import com.vaadin.spring.annotation.SpringUI;
import com.vaadin.ui.Button;
import com.vaadin.ui.Label;
import com.vaadin.ui.Notification;
import com.vaadin.ui.UI;
import com.vaadin.ui.VerticalLayout;

@SpringUI(path = "/home")
@Title("Vaadin page")
public class HomeUI extends UI {

    @Override
    protected void init(VaadinRequest request) {
        
        VerticalLayout layout = new VerticalLayout();

        Label label = new Label("Integración Spring Boot - Vaadin");
        Button button = new Button("click", e -> Notification.show("Hola Vaadin/Spring Boot"));
        
        layout.addComponent(label);
        layout.addComponent(button);

        setContent(layout);
    }
}

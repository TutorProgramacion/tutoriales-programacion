#include <QCoreApplication>
#include <QSql>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QVariant>

#include <iostream>

using namespace std;

void createTablePerson()
{
    QSqlQuery query;

    if(query.exec("CREATE TABLE person(id int primary key, name varchar(50), lastname varchar(50), age int);"))
    {
        cout << "Tabla [PERSON] creada correctamente." << endl;
    }
    else
    {
        cout << query.lastError().text().toStdString() << endl;
    }
}

void insertDataPerson()
{
    QSqlQuery query;

    query.exec("INSERT INTO person(id, name, lastname, age) VALUES (1, 'Juan', 'Perez', 18);");
    query.exec("INSERT INTO person(id, name, lastname, age) VALUES (2, 'Ana', 'Maria', 19);");
    query.exec("INSERT INTO person(id, name, lastname, age) VALUES (3, 'Maria', 'Lopez', 20);");
    query.exec("INSERT INTO person(id, name, lastname, age) VALUES (4, 'Luis', 'Diaz', 28);");
}

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName("localhost");
    db.setPort(3306);
    db.setUserName("root");
    db.setPassword("159159");
    db.setDatabaseName("tutorial");

    if(db.open())
    {
        cout << "Conexion a [SQLITE] preparada." << endl << endl;

        // comprobar si existe la tabla person
        if(!db.tables().contains("person")) {
            createTablePerson();
            insertDataPerson();
        }

        QSqlQuery query;
        query.exec("SELECT * FROM person;");

        while(query.next()) {

            int id = query.value(0).toInt();
            int age = query.value(3).toInt();

            string name = query.value(1).toString().toStdString();
            string lastname = query.value(2).toString().toStdString();

            cout << id << ", " << name << ", " << lastname << ", " << age << endl;
        }

        db.close();
    }

    return a.exec();
}

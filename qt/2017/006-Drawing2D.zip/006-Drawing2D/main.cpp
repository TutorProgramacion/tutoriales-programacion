#include "drawingtest.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    DrawingTest w;
    w.setWindowTitle("Qt Drawing");
    w.show();

    return a.exec();
}

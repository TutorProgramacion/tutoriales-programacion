#ifndef DRAWINGTEST_H
#define DRAWINGTEST_H

#include <QWidget>

class DrawingTest : public QWidget
{
    Q_OBJECT

public:
    DrawingTest(QWidget *parent = 0);

protected:
    void paintEvent(QPaintEvent *event) override;

};

#endif // DRAWINGTEST_H

#include "drawingtest.h"
#include <QPainter>
#include <QTimer>

DrawingTest::DrawingTest(QWidget *parent) : QWidget(parent) {

    QTimer *timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(update()));
    timer->start(10);
}

void DrawingTest::paintEvent(QPaintEvent *event)
{
    static int angle = 0;

    QPainter painter;
    painter.begin(this);
    painter.setRenderHint(QPainter::Antialiasing);

//    QPen pen;
//    pen.setColor(Qt::red);
//    pen.setWidth(3);
//    pen.setStyle(Qt::DotLine);

//    painter.setPen(pen);

//    painter.drawLine(10, 10, 100, 100);
//    painter.drawRoundedRect(QRect(10, 60, 100, 50), 10, 10);
//    painter.drawArc(QRect(150, 50, 100, 100), 0, 180 * 16);

//    painter.scale(2, 2);
//    painter.translate(100, -100);
//    painter.rotate(25);

//    painter.setFont(QFont("Roboto Light", 20));
//    painter.setPen(qRgb(125, 88, 212));
//    painter.drawText(QRect(10, 150, 250, 50), "Hello Paint Qt");

//    painter.rotate(angle++);
    painter.drawImage(QRect(60, 50, 500, 333), QImage(":/tomcat-logo.png"));

    painter.end();
}

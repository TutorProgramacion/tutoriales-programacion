#include <QApplication>
#include <QWidget>
#include <QIcon>
#include <QPushButton>
#include <QLabel>
#include <QFont>

class Ventana : public QWidget
{
public:
    Ventana(QWidget *parent = 0);
};

Ventana::Ventana(QWidget *parent) : QWidget(parent)
{
    QPushButton* btn = new QPushButton("Salir", this);
    btn->setGeometry(340, 160, 250, 30);

    connect(btn, &QPushButton::clicked, this, &QWidget::close);

    QLabel* lbl = new QLabel(this);
    lbl->setGeometry(130, 10, 300, 30);
    lbl->setFont(QFont("Segoe UI", 12));
    lbl->setText("Tutor de programación <b>Qt 5.x</b> 2017");

}

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    Ventana ventana;
    ventana.resize(600, 200);
    ventana.setWindowIcon(QIcon(":/icon/designer.png"));
    ventana.setWindowTitle("Qt 5.x :: My primera ventana");
    ventana.show();

    return app.exec();
}

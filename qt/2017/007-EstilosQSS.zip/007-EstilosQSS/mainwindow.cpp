#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    ui->comboBox->addItem("Primarios");
    ui->comboBox->addItem("Secundarios");
    ui->comboBox->addItem("Universidad");
}

MainWindow::~MainWindow()
{
    delete ui;
}

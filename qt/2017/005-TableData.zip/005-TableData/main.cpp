#include "mainwindow.h"
#include <QApplication>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>


void dataPerson()
{
    QSqlQuery query;

    query.exec("CREATE TABLE person(id int primary key, name varchar(50), lastname varchar(50), age int);");

    query.exec("INSERT INTO person(id, name, lastname, age) VALUES (1, 'Juan', 'Perez', 18);");
    query.exec("INSERT INTO person(id, name, lastname, age) VALUES (2, 'Ana', 'Maria', 19);");
    query.exec("INSERT INTO person(id, name, lastname, age) VALUES (3, 'Maria', 'Lopez', 20);");
    query.exec("INSERT INTO person(id, name, lastname, age) VALUES (4, 'Luis', 'Diaz', 28);");
}


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(":memory:");

    if(db.open()) {
        dataPerson();
    }

    MainWindow w;
    w.show();

    db.close();

    return a.exec();
}

#include "mainwindow.h"

#include <QTableWidget>
#include <QVBoxLayout>
#include <QHeaderView>
#include <QtSql/QSqlQuery>

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent)
{

    QTableWidget *table = new QTableWidget(10, 4);

    QStringList headers = { "ID", "NOMBRE", "APELLIDO", "EDAD" };
    table->setHorizontalHeaderLabels(headers);

    QSqlQuery query;
    query.exec("SELECT * FROM person;");

    int row = 0;

    while(query.next())
    {
        QTableWidgetItem *idItem = new QTableWidgetItem(query.value(0).toString());
        table->setItem(row, 0, idItem);

        QTableWidgetItem *nameItem = new QTableWidgetItem(query.value(1).toString());
        table->setItem(row, 1, nameItem);

        QTableWidgetItem *lastItem = new QTableWidgetItem(query.value(2).toString());
        table->setItem(row, 2, lastItem);

        QTableWidgetItem *ageItem = new QTableWidgetItem(query.value(3).toString());
        table->setItem(row, 3, ageItem);

        row++;
    }

    setCentralWidget(table);
    setWindowTitle("QTableWidget");
}

MainWindow::~MainWindow()
{

}

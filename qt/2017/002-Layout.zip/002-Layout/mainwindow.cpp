#include "mainwindow.h"

MainWindow::MainWindow(QWidget *parent) : QWidget(parent)
{

    QVBoxLayout* rootLayout = new QVBoxLayout(this);


    QHBoxLayout* btnLayout = new QHBoxLayout();

    QPushButton* btnAceptar = new QPushButton("Aceptar", this);
    QPushButton* btnCancelar = new QPushButton("Cancelar", this);

    btnLayout->setSpacing(10);
    btnLayout->addStretch(1);
    btnLayout->addWidget(btnAceptar);
    btnLayout->addWidget(btnCancelar);


    QFormLayout* formLayout = new QFormLayout();

    QLineEdit *nombreEdit = new QLineEdit(this);
    QLineEdit *correoEdit = new QLineEdit(this);
    QLineEdit *edadEdit = new QLineEdit(this);

    QTextEdit *descEdit = new QTextEdit(this);
    descEdit->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    descEdit->setPlaceholderText("escriba una breve descripcion...");

    formLayout->setLabelAlignment(Qt::AlignRight | Qt::AlignVCenter);
    formLayout->addRow("Nombre:", nombreEdit);
    formLayout->addRow("Correo:", correoEdit);
    formLayout->addRow("Edad:", edadEdit);
    formLayout->addRow("Descripcion:", descEdit);

    rootLayout->addLayout(formLayout);
    rootLayout->addLayout(btnLayout);

    setLayout(rootLayout);

/*
    QGridLayout *grid = new QGridLayout(this);
    grid->setSpacing(2);

    QLineEdit* edit = new QLineEdit(this);
    edit->setFixedHeight(50);
    edit->setFont(QFont("Consolas", 20));

    grid->addWidget(edit, 0, 0, 1, 4);

    QList<QString> values({
        "7", "8", "9", "/",
        "4", "5", "6", "*",
        "1", "2", "3", "-",
        "0", ".", "=", "+"
    });

    for (int i = 1, pos = 0; i <= 4; i++) {
        for (int j = 0; j < 4; j++) {
            QPushButton *btn = new QPushButton(values[pos++], this);
            btn->setFixedSize(80, 80);
            grid->addWidget(btn, i, j);
        }
    }

    setLayout(grid);
*/
}

MainWindow::~MainWindow() { }

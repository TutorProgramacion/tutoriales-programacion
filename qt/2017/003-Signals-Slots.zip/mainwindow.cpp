#include "mainwindow.h"

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent)
{
    this->setWindowTitle("Signals & Slots");
    this->resize(600, 250);

    btn = new QPushButton("Salir (0)", this);
    btn->setGeometry(10, 10, 120, 30);

    QObject::connect(btn, &QPushButton::clicked, this, &MainWindow::OnClickSalir);
    QObject::connect(this, &MainWindow::MaxClickCount, this, &MainWindow::close);
}

void MainWindow::OnClickSalir()
{
    if(this->clickCount++ >= 5) {
        emit MaxClickCount();
    }

    this->btn->setText(QString::asprintf("Salir (%d)", this->clickCount));
}

MainWindow::~MainWindow() { }

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPushButton>
#include <QMessageBox>

class MainWindow : public QMainWindow
{
    Q_OBJECT

public slots:
    void OnClickSalir();

signals:
    void MaxClickCount();

public:
    MainWindow(QWidget *parent = 0);
    ~MainWindow();

private:
    QPushButton *btn = 0;
    int clickCount = 0;
};

#endif // MAINWINDOW_H

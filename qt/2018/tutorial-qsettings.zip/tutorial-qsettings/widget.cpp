#include "widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
{
    font = new QFontComboBox;
    font->setFontFilters(QFontComboBox::ScalableFonts);

    size = new QComboBox;
    size->setMaximumWidth(100);

    for(int n = 5; n <= 100; n += 5) size->addItem(QVariant(n).toString());

    label = new QLabel;
    label->setText("Tutorial QSettings");
    label->setAlignment(Qt::AlignCenter);

    QHBoxLayout *fontLayout = new QHBoxLayout;
    fontLayout->addWidget(font);
    fontLayout->addWidget(size);

    QVBoxLayout *root = new QVBoxLayout;
    root->addLayout(fontLayout);
    root->addWidget(label);

    this->setLayout(root);

    QSettings settings("miapp.ini", QSettings::IniFormat);
    QRect geo = settings.value("geometry", QRect(20, 20, 200, 100)).toRect();
    QFont fnt = settings.value("font").value<QFont>();
    QString fsize = settings.value("fsize", 10).toString();

    this->setGeometry(geo);
    this->font->setCurrentFont(fnt);
    this->size->setCurrentText(fsize);

    QFont actualFont = fnt;
    actualFont.setPointSize(fsize.toInt());

    label->setFont(actualFont);

    QObject::connect(font, &QFontComboBox::currentFontChanged, this, &Widget::updateLabel);
    QObject::connect(size, &QComboBox::currentTextChanged, this, &Widget::updateLabel);
}

void Widget::closeEvent(QCloseEvent*)
{
   QSettings settings("miapp.ini", QSettings::IniFormat);
   settings.setValue("geometry", this->geometry());
   settings.setValue("font", this->font->currentFont());
   settings.setValue("fsize", this->size->currentText());
}

void Widget::updateLabel()
{
    QFont actual = this->font->currentFont();
    actual.setPointSize(this->size->currentText().toInt());

    label->setFont(actual);
}


Widget::~Widget()
{

}

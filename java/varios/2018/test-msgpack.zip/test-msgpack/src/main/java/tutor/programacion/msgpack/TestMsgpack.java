/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tutor.programacion.msgpack;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import java.io.File;
import java.io.IOException;
import org.msgpack.core.MessageBufferPacker;
import org.msgpack.core.MessagePack;
import org.msgpack.core.MessageUnpacker;
import org.msgpack.jackson.dataformat.MessagePackFactory;

/**
 *
 * @author Carmelo
 */
public class TestMsgpack {

    public static void main(String[] args) throws IOException {

        TestMsgpack tmp = new TestMsgpack();
//        tmp.packPrimitives();
        tmp.packJackson();
    }

    private void packJackson() throws IOException {

        // objeto a serializar
        Person p = new Person();
        p.setAge(15);
        p.setGender(true);
        p.setName("Tutorial");

        // archivo binario para crear 
        File file = new File("binary.dat");
        
        // jackson ObjectMapper
        ObjectMapper mapper = new ObjectMapper(new MessagePackFactory());
        
        // escribir el objeto Person
        mapper.writeValue(file, p);
        
        // leer el objeto Person
        Person person = mapper.readValue(file, Person.class);
        
        System.out.println(person);
    }

    private void packPrimitives() throws IOException {

        // crear objeto MessagePacker (encoder) 
        MessageBufferPacker packer = MessagePack.newDefaultBufferPacker();

        // codificar los tipos primitivos
        packer.packBoolean(true);
        packer.packShort((short) 34);
        packer.packInt(1);
        packer.packLong(33000000000L);

        packer.packFloat(0.1f);
        packer.packDouble(3.14159263);
        packer.packByte((byte) 0x80);

        // pack String
        packer.packString("hello message pack!");

        // pack arrays
        int[] arr = new int[]{10, 20, 30, 40, 50, 60, 70, 80, 90};
        packer.packArrayHeader(arr.length);
        for (int v : arr) {
            packer.packInt(v);
        }

        // pack Map, indicamos la cantidad de elementos
        packer.packMapHeader(2);

        // primer elemento del Map
        packer.packString("apple"); // clave
        packer.packInt(1);          // valor

        // segundo elemento del Map
        packer.packString("banana"); // clave
        packer.packInt(2);           // valor

        packer.close();

        // obtener el arreglo de bytes
        byte[] out = packer.toByteArray();

        // crear objeto MessageUnpaker (decoder)
        MessageUnpacker unpacker = MessagePack.newDefaultUnpacker(out);

        // decodificar los datos primitivos 
        System.out.println("boolean: " + unpacker.unpackBoolean());
        System.out.println("short: " + unpacker.unpackShort());
        System.out.println("int: " + unpacker.unpackInt());
        System.out.println("long: " + unpacker.unpackLong());

        // debemos leer estos datos antes de tratar de acceder al String
        unpacker.unpackFloat();
        unpacker.unpackDouble();
        unpacker.unpackByte();

        System.out.println("texto: " + unpacker.unpackString());

        System.out.println("\nArreglo int");

        int length = unpacker.unpackArrayHeader();

        for (int i = 0; i < length; i++) {
            System.out.println("int [" + i + "] : " + unpacker.unpackInt());
        }

        System.out.println("\nMap clave/valor");
        int cantidad = unpacker.unpackMapHeader();

        for (int i = 0; i < cantidad; i++) {
            System.out.println("clave: " + unpacker.unpackString() + ", valor: " + unpacker.unpackInt());
        }

        unpacker.close();
    }
}

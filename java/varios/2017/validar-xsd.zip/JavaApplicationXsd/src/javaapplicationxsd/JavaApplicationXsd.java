package javaapplicationxsd;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.XMLConstants;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.util.JAXBSource;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import org.xml.sax.SAXException;
import test.Person;

public class JavaApplicationXsd {

    public static void main(String[] args) {

        try {

            Person person = new Person();
            person.setId(111);
            person.setAge(200);
            person.setName("Tutorprogramacion");
            person.setGender("X");

            // instanciar una fabrica de esquemas
            SchemaFactory factory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);

            // cargar el esquema XSD
            StreamSource validator = new StreamSource(JavaApplicationXsd.class.getResourceAsStream("test.xsd"));
            Schema schema = factory.newSchema(validator);

            // create JAXB context and instantiate marshaller
            JAXBContext context = JAXBContext.newInstance(Person.class);

//            try {
//                Validator xsdValidator = schema.newValidator();
//                xsdValidator.setErrorHandler(new CustomValidationErrorHandler());
//                xsdValidator.validate(new JAXBSource(context, person));
//                
//            } catch (IOException ex) {
//                System.out.println("Error en validacion");
//            }

            // crear el marshaller y formatear la salida, solo para mejor visualizacion
            Marshaller m = context.createMarshaller();
            m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
            m.setSchema(schema);
            m.setEventHandler(handler -> {
                System.out.println("ERROR: " + handler.getMessage());
                return true;
            });

            m.marshal(person, System.out);

        } catch (JAXBException | SAXException ex) {
            ex.printStackTrace();
        }
    }
}

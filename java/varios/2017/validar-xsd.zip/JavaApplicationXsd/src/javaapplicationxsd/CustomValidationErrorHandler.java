package javaapplicationxsd;

import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

public class CustomValidationErrorHandler implements ErrorHandler {
     
    @Override
    public void warning(SAXParseException ex) throws SAXException {
        System.out.println("WARNING: " + ex.getLocalizedMessage());
    }
  
    @Override
    public void error(SAXParseException ex) throws SAXException {
        System.out.println("ERROR: " + ex.getLocalizedMessage());
    }
  
    @Override
    public void fatalError(SAXParseException ex) throws SAXException {
        System.out.println("FATAL ERROR: " + ex.getLocalizedMessage());
    }
 
}
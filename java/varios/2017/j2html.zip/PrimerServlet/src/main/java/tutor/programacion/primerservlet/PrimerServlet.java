package tutor.programacion.primerservlet;

import static j2html.TagCreator.*;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/")
public class PrimerServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");

        html(
                header(
                        title("Tutor de programacion")
                ),
                body(
                        h1("J2HTML en Servlet Tutorial"),
                        p("Contenido generado dinamicamente con j2html, creado en 2017"),
                        a("Tutor de programación").withHref("http://acodigo.blogspot.com"),
                        br(), br(),
                        each(filter(Tutoriales.getAll(), t -> t.getCantidad() > 20), tutorial
                                -> div(
                                a(tutorial.getNombre()).withHref(tutorial.getEnlace()),
                                span(" (" + tutorial.getCantidad() + ")")
                                )
                        )
                )
        ).render(response.getWriter());
    }
}

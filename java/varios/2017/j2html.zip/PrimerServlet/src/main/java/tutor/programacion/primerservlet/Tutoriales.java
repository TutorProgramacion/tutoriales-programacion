
package tutor.programacion.primerservlet;

import java.util.Arrays;
import java.util.List;


public class Tutoriales {
    
    private String nombre;
    private String enlace;
    private Integer cantidad;

    public Tutoriales(String nombre, String enlace, Integer cantidad) {
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.enlace = enlace;
    }
    
    public static List<Tutoriales> getAll() {
        return Arrays.asList(
                new Tutoriales("OpenCV", "http://acodigo.blogspot.com/p/tutorial-opencv.html", 50),
                new Tutoriales("JavaFX", "http://acodigo.blogspot.com/p/java.html", 20),
                new Tutoriales("Python Qt", "http://acodigo.blogspot.com/p/python.html", 30),
                new Tutoriales("OpenGL", "http://acodigo.blogspot.com/p/python.html", 12),
                new Tutoriales("Spring MVC", "http://acodigo.blogspot.com/p/spring.html", 43)
        );
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Integer getCantidad() {
        return cantidad;
    }

    public void setCantidad(Integer cantidad) {
        this.cantidad = cantidad;
    }

    public void setEnlace(String enlace) {
        this.enlace = enlace;
    }

    public String getEnlace() {
        return enlace;
    }

}

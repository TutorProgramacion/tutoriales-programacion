package tutor.javafx;

import java.net.URL;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import javafx.beans.property.SimpleStringProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public class FXMLDocumentController implements Initializable {

    private Connection connection;

    @FXML
    private ComboBox<String> cbxBasesDatos;
    @FXML
    private ListView<String> lvTables;

    @FXML
    private TextField txtUrl;
    @FXML
    private TextField txtUser;
    @FXML
    private TextField txtPassword;

    @FXML
    private TableView<Map<String, String>> tvColumns;
    @FXML
    private TableColumn<Map<String, String>, String> tcColumnName;
    @FXML
    private TableColumn<Map<String, String>, String> tcTypeName;
    @FXML
    private TableColumn<Map<String, String>, String> tcColumnSize;
    @FXML
    private TableColumn<Map<String, String>, String> tcIsNullable;
    

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        tcColumnName.setCellValueFactory(v -> cellValueFactory(v));
        tcColumnSize.setCellValueFactory(v -> cellValueFactory(v));
        tcTypeName.setCellValueFactory(v -> cellValueFactory(v));
        tcIsNullable.setCellValueFactory(v -> cellValueFactory(v));

        cbxBasesDatos.setOnAction(e -> tablesMetadata(connection));
        lvTables.getSelectionModel().selectedItemProperty().addListener((p, o, n) -> {
            if (n != null) {
                columnsMetadata(connection);
            }
        });

    }

    private SimpleStringProperty cellValueFactory(CellDataFeatures<Map<String, String>, String> value) {
        return new SimpleStringProperty(value.getValue().get(value.getTableColumn().getText()));
    }

    @FXML
    private void onClickActualizar(ActionEvent event) {
        try {

            final String url = txtUrl.getText();
            final String username = txtUser.getText();
            final String password = txtPassword.getText();

            connection = DriverManager.getConnection(url, username, password);
            catalogsMetadata(connection);

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void catalogsMetadata(Connection con) throws SQLException {

        DatabaseMetaData metadata = con.getMetaData();
        ResultSet rs = metadata.getCatalogs();

        cbxBasesDatos.getItems().clear();

        while (rs.next()) {
            cbxBasesDatos.getItems().add(rs.getString("TABLE_CAT"));
        }
    }

    public void tablesMetadata(Connection con) {
        try {

            String catalog = cbxBasesDatos.getValue();

            DatabaseMetaData metadata = con.getMetaData();
            ResultSet rs = metadata.getTables(catalog, null, null, new String[]{"TABLE"});

            lvTables.getItems().clear();

            while (rs.next()) {
                lvTables.getItems().add(rs.getString("TABLE_NAME"));
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void columnsMetadata(Connection conn) {
        try {

            DatabaseMetaData metadata = conn.getMetaData();

            String catalog = cbxBasesDatos.getValue();
            String table = lvTables.getSelectionModel().getSelectedItem();

            ResultSet rs = metadata.getColumns(catalog, null, table, null);

            List<Map<String, String>> items = new ArrayList<>();
            
            while (rs.next()) {
                
                Map<String, String> row = new HashMap<>();
                
                tvColumns.getColumns().forEach(c -> {
                    try {
                        String data = c.getText();
                        row.put(data, rs.getString(data));
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                });
                
                items.add(row);
            }
            
            tvColumns.getItems().setAll(items);

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

}

package tutor;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ConectarMySQL {

    public static void main(String[] args) {

        try {

            String url = "jdbc:mysql://localhost:3306/";
            String username = "root";
            String password = "159159";

            try (Connection connection = DriverManager.getConnection(url, username, password)) {
                tableInfo(connection);
                catalogInfo(connection);
                columnInfo(connection);
                generalInfo(connection);
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private static void tableInfo(Connection connection) throws SQLException {
        
        System.out.println("--- Tablas de la BD [sakila] ---");
        
        DatabaseMetaData metadata = connection.getMetaData();
        ResultSet rs = metadata.getTables("sakila", null, null, new String[]{"TABLE"});

        while (rs.next()) {
            System.out.println(rs.getString("TABLE_NAME"));
        }

        System.out.println("\n");
    }

    private static void columnInfo(Connection connection) throws SQLException {
        
        System.out.println("--- Columnas de la tabla [actor] en la BD [sakila] ---");
        
        DatabaseMetaData metadata = connection.getMetaData();
        ResultSet rs = metadata.getColumns("sakila", null, "actor", null);

        while (rs.next()) {
            System.out.println(
                    rs.getString("COLUMN_NAME") + ", "
                    + rs.getString("TYPE_NAME") + ", "
                    + rs.getString("COLUMN_SIZE"));
        }

        System.out.println("\n");
    }

    private static void catalogInfo(Connection connection) throws SQLException {
        
        System.out.println("--- Tablas en Base de datos ---");
        
        DatabaseMetaData metadata = connection.getMetaData();
        ResultSet rs = metadata.getCatalogs();

        while (rs.next()) {
            System.out.println(rs.getString("TABLE_CAT"));
        }

        System.out.println("\n");
    }

    private static void generalInfo(Connection connection) throws SQLException {

        System.out.println("--- Informacion general ---");
        
        DatabaseMetaData meta = connection.getMetaData();

        System.out.println("DatabaseProductName:    " + meta.getDatabaseProductName());
        System.out.println("DatabaseProductVersion: " + meta.getDatabaseProductVersion());
        System.out.println("UserName:               " + meta.getUserName());
        System.out.println("URL:                    " + meta.getURL());
        System.out.println("DriverName:             " + meta.getDriverName());
        System.out.println("DriverVersion:          " + meta.getDriverVersion());

        ResultSet rs = meta.getTypeInfo();

        System.out.println("TypeInfo: ");
        while (rs.next()) {
            System.out.println("\t" + rs.getString(1));
        }
    }

}

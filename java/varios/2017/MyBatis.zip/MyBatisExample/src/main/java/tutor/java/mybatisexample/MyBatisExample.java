package tutor.java.mybatisexample;

import java.util.List;
import javax.sql.DataSource;
import org.apache.ibatis.datasource.pooled.PooledDataSource;
import org.apache.ibatis.mapping.Environment;
import org.apache.ibatis.session.Configuration;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.apache.ibatis.transaction.TransactionFactory;
import org.apache.ibatis.transaction.jdbc.JdbcTransactionFactory;

public class MyBatisExample {

    public static void main(String[] args) {
        
        DataSource dataSource = getDataSource();

        TransactionFactory transactionFactory = new JdbcTransactionFactory();
        Environment environment = new Environment("development", transactionFactory, dataSource);

        Configuration configuration = new Configuration(environment);
        configuration.addMapper(CustomerMapper.class);

        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(configuration);

        try (SqlSession session = sqlSessionFactory.openSession()) {
            
            CustomerMapper mapper = session.getMapper(CustomerMapper.class);
            Customer customer = mapper.selectCustomerById(10);
            
            System.out.println(customer);
            
            List<Customer> all = mapper.selectAllCustomer();
            all.forEach(System.out::println);
        }
    }

    private static DataSource getDataSource() {
        PooledDataSource ds = new PooledDataSource();
        ds.setDriver("org.hsqldb.jdbcDriver");
        ds.setUrl("jdbc:hsqldb:hsql://localhost/");
        ds.setUsername("SA");
        ds.setPassword("");
        return ds;
    }

}

package tutor.programacion.sparktutorial;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.thymeleaf.context.Context;
import org.thymeleaf.context.IContext;

import static spark.Spark.get;
import static spark.Spark.port;

public class SparkApplication {

    public static void main(String[] args) {

        port(8088);
        
        get("/hello", (req, res) -> {
            
            Map<String, Object> variables = new HashMap<>();
            variables.put("today", new Date());

            IContext context = new Context(req.raw().getLocale(), variables);
            String out = ThymeleafUtil.getTemplateEngine().process("home", context);

            return out;
        });
    }
}

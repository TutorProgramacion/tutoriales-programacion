package tutor.programacion.primerservlet;

import java.io.IOException;
import java.util.Locale;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

@WebFilter("/*")
public class PrimerFiltro implements Filter {

    @Override
    public void init(FilterConfig config) throws ServletException {
        // nada por ahora...
    }

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {
        
        String idioma = req.getParameter("idioma");
 
        if(idioma != null) {
            if(idioma.equals("es") || idioma.equals("en")) {
                res.setLocale(new Locale(idioma));
            }
        } 
        
        chain.doFilter(req, res);    
    }

    @Override
    public void destroy() {
        // nada por ahora...
    }
}

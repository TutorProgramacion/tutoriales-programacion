package carmelo.servlet;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class MyFiltro implements Filter {

    @Override
    public void init(FilterConfig fc) throws ServletException {
        // hacer algo al inicializar
    }

    @Override
    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain fc) 
            throws IOException, ServletException {
        
        resp.setContentType("text/plain");
        
        fc.doFilter(req, resp);
    }

    @Override
    public void destroy() {
        // hacer algo al destruir
    }
   
}

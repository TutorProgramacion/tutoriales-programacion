package tutor.programacion.primerservlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/")
public class PrimerServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");

        PrintWriter out = response.getWriter();

        Enumeration<String> headers = request.getHeaderNames();
        while (headers.hasMoreElements()) {
            String h = headers.nextElement();
            out.println( h + " : " + request.getHeader(h) + "<br />");
        }
        
        out.println("Metodo HTTP: " + request.getMethod() + "<br />");
        out.println("URI Peticion: " + request.getRequestURI() + "<br />");
        out.println("Protocolo: " + request.getProtocol() + "<br />");

//        out.println("<h1>Java Servlet Tutorial</h1>");
//        out.println("<p>Este es mi primer <b>Servlet</b>.</p>");
//        out.println("<p>Por: <a href=\"http://acodigo.blogspot.com\">Tutor de Programacion</a> </p>");
    }
}

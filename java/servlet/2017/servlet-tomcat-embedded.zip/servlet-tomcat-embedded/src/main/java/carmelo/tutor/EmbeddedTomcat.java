package carmelo.tutor;

import java.io.File;
import org.apache.catalina.Context;
import org.apache.catalina.LifecycleException;
import org.apache.catalina.startup.Tomcat;

public class EmbeddedTomcat {

    public static void main(String[] args) throws LifecycleException {
        
        Tomcat tomcat = new Tomcat();
        tomcat.setPort(8888);

        Context ctx = tomcat.addContext("/", new File(".").getAbsolutePath());
        
        Tomcat.addServlet(ctx, "MyServletName", new MyServlet());      
        ctx.addServletMapping("/*", "MyServletName");

        tomcat.start();
        tomcat.getServer().await();
    }
}
